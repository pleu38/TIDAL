<?php
/* Smarty version 3.1.33, created on 2019-09-30 14:56:41
  from 'C:\Keil\USBWebserver_8.6.2\USBWebserver 8.6.2\root\appli\templates\defaut.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5d9217a9311d95_73972360',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bbb10efe0f42a05cbd1fe87c3db5fc2a0674ac87' => 
    array (
      0 => 'C:\\Keil\\USBWebserver_8.6.2\\USBWebserver 8.6.2\\root\\appli\\templates\\defaut.tpl',
      1 => 1569855398,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5d9217a9311d95_73972360 (Smarty_Internal_Template $_smarty_tpl) {
?><!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
		<meta name="description" content="whatever"/>
		<link href="styles/style.css" rel="stylesheet" type="text/css"/>
		<?php echo '<script'; ?>
 type="text/javascript" src="js/pathos.js" charset="utf-8"><?php echo '</script'; ?>
>
	</head>
	<body>
	<div id="content">
		<p>Pas de template associé</p>
		<p>Essayez peut-être <a href="?action=test">?action=test</a>?</p>
	</div>
</body>
</html>
<?php }
}
