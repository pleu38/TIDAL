<?php
/* Smarty version 3.1.33, created on 2019-09-12 15:26:39
  from 'C:\wamp64\www\appli\templates\bdd.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5d7a63af5b3657_00410383',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '639424c2897686863995665ff01140196e96e91e' => 
    array (
      0 => 'C:\\wamp64\\www\\appli\\templates\\bdd.tpl',
      1 => 1568301858,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5d7a63af5b3657_00410383 (Smarty_Internal_Template $_smarty_tpl) {
?><!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
		<meta name="description" content="whatever"/>
		<link href="styles/style.css" rel="stylesheet" type="text/css"/>
		<?php echo '<script'; ?>
 type="text/javascript" src="js/pathos.js" charset="utf-8"><?php echo '</script'; ?>
>
	</head>
	<body>
	<div id="content">
		<aside>
			<div id="menu">
				<ul>
					<li><a href="http://acupuncture.mascret.fr/index.php?action=accueil">Accueil</a></li>
					<li><a href="http://acupuncture.mascret.fr/index.php?action=truc">Truc</a></li>
					<li><a href="http://acupuncture.mascret.fr/index.php?action=pathos">pathologies</a></li>
				</ul>
			</div>
		</aside>
		
		<div id="recap">
			<p>Bienvenue <?php echo $_smarty_tpl->tpl_vars['userFirstName']->value;?>
!</p>
			<form action="index.php?action=logout" method="post">
				<input type="submit" name="logout" value="Déconnexion"/>
			</form>
		</div>
		
		<h1>Pathologies en acupuncture</h1>
		<form action="" method="post">
			<fieldset id="fs_mer">
				<legend>Méridiens et Merveilleux Vaisseaux</legend>
				
				<div class="inputMer">
					<ul>
						<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data']->value, 'foo1');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['foo1']->value) {
?>
							<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['foo1']->value, 'foo');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['foo']->value) {
?>
								<li>
									<?php echo $_smarty_tpl->tpl_vars['foo']->value;?>

								</li>
							<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
						<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
					</ul>

				</div>		
	</body>
</html>
<?php }
}
