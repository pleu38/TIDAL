<?php
/* Smarty version 3.1.33, created on 2019-10-14 15:07:50
  from 'C:\Keil\USBWebserver_8.6.2\USBWebserver 8.6.2\root\appli\templates\bdd.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5da48f46aaa789_83228718',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cc78e595271bbcdd627c1e2e1cc9b6e88ea402a1' => 
    array (
      0 => 'C:\\Keil\\USBWebserver_8.6.2\\USBWebserver 8.6.2\\root\\appli\\templates\\bdd.tpl',
      1 => 1571065620,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
  ),
),false)) {
function content_5da48f46aaa789_83228718 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
		
		<h1>Pathologies en acupuncture</h1>
		<form action="?action=affichage" method="post">
			<fieldset id="fs_mer">
				<legend>Méridiens et Merveilleux Vaisseaux</legend>
				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data']->value, 'row');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['row']->value) {
?>
				<div class="inputMer">
					<ul>
						<li>
							<input type="checkbox" name="<?php echo $_smarty_tpl->tpl_vars['row']->value['code'];?>
" id="<?php echo $_smarty_tpl->tpl_vars['row']->value['code'];?>
"><label for="<?php echo $_smarty_tpl->tpl_vars['row']->value['code'];?>
"><?php echo $_smarty_tpl->tpl_vars['row']->value['nom'];?>
</label>
						</li>						
					</ul>
				</div>
				<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
				<input type="button" value="Tout cocher" onclick="this.value=check('fs_mer')">
				<input type="submit" value="Appliquer">
			</fieldset>	
			<fieldset id="fs_patho">
				<legend>Endroit de la douleur</legend>
				<div class="inputPatho">
					<ul>
					<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['douleur']->value, 'row');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['row']->value) {
?>
						<li>
							<input type="checkbox" name="<?php echo $_smarty_tpl->tpl_vars['row']->value['mer'];?>
" id="<?php echo $_smarty_tpl->tpl_vars['row']->value['mer'];?>
"><label for="<?php echo $_smarty_tpl->tpl_vars['row']->value['desc'];?>
"><?php echo $_smarty_tpl->tpl_vars['row']->value['desc'];?>
</label>
						</li>
					<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
					</ul>
				</div>	
				<input type="button" value="Tout cocher" onclick="this.value=check('fs_mer')">
			</fieldset>								
		</form>	
							
	</body>
</html>
<?php }
}
