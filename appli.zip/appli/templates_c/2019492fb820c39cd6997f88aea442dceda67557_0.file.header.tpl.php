<?php
/* Smarty version 3.1.33, created on 2019-10-14 15:13:40
  from 'C:\Keil\USBWebserver_8.6.2\USBWebserver 8.6.2\root\appli\templates\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5da490a4cbdb87_47998647',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2019492fb820c39cd6997f88aea442dceda67557' => 
    array (
      0 => 'C:\\Keil\\USBWebserver_8.6.2\\USBWebserver 8.6.2\\root\\appli\\templates\\header.tpl',
      1 => 1571065976,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5da490a4cbdb87_47998647 (Smarty_Internal_Template $_smarty_tpl) {
?><!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
		<meta name="description" content="whatever"/>
		<link href="styles/style.css" rel="stylesheet" type="text/css"/>
		<?php echo '<script'; ?>
 type="text/javascript" src="js/pathos.js" charset="utf-8"><?php echo '</script'; ?>
>
	</head>
	<body>
	<div id="content">
		<aside>
			<div id="menu">
				<ul>
					<li><a href="?action=bdd">Accueil</a></li>
					<!--<li><a href="">Truc</a></li>-->
					<li><a href="http://localhost/appli/?action=bdd">Pathologies</a></li>
					<li><a href="http://localhost/appli/?action=fil">Filtre</a></li>
				</ul>
			</div>
		</aside>
		
		<div id="recap">
			<p>Bienvenue <?php echo $_smarty_tpl->tpl_vars['userFirstName']->value;?>
!</p>
			<form action="action_page.php" method="post">

			  <!-- <div class="container">
				<label for="uname"><b>Username</b></label>
				<input type="text" placeholder="Enter Username" name="uname" required>

				<label for="psw"><b>Password</b></label>
				<input type="password" placeholder="Enter Password" name="psw" required>
				<p>
				<button type="submit">Login</button>
				
				  <input type="checkbox" checked="checked" name="remember"> Remember me
				</p>
			  </div> -->

			  <div class="container" style="background-color:#f1f1f1">
				<button type="button" class="cancelbtn">Cancel</button>
				<p>
				<span class="psw">Forgot <a href="#">password?</a></span>
				<p>
			  </div>
			</form>
		</div><?php }
}
