<?php
/* Smarty version 3.1.33, created on 2019-10-14 11:55:31
  from 'C:\Keil\USBWebserver_8.6.2\USBWebserver 8.6.2\root\appli\templates\fil.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5da46233347d87_36568579',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '58a7cc56237bf8bf4412c99e00e7979ca06db708' => 
    array (
      0 => 'C:\\Keil\\USBWebserver_8.6.2\\USBWebserver 8.6.2\\root\\appli\\templates\\fil.tpl',
      1 => 1570995606,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5da46233347d87_36568579 (Smarty_Internal_Template $_smarty_tpl) {
?><!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
		<meta name="description" content="whatever"/>
		<link href="styles/style.css" rel="stylesheet" type="text/css"/>
		<?php echo '<script'; ?>
 type="text/javascript" src="js/pathos.js" charset="utf-8"><?php echo '</script'; ?>
>
	</head>
	<body>
	<div id="content">
		<aside>
			<div id="menu">
				<ul>
					<li><a href="">Accueil</a></li>
					<li><a href="">Truc</a></li>
					<li><a href="http://localhost/appli/?action=bdd">Pathologies</a></li>
					<li><a href="http://localhost/appli/?action=fil">Filtre</a></li>
				</ul>
			</div>
		</aside>
		
		<div id="recap">
			<p>Bienvenue <?php echo $_smarty_tpl->tpl_vars['userFirstName']->value;?>
!</p>
			<form action="index.php?action=logout" method="post">
				<input type="submit" name="logout" value="Déconnexion"/>
			</form>
		</div>
		
		<h1>Pathologies en acupuncture</h1>
		<form action="" method="post">
					<fieldset id="fs_patho">
						<legend>Endroit de la douleur</legend>
							<div class="inputPatho">
								<ul>

								</ul>
							</div>	
					</fieldset>
			
			<fieldset id="fs_mer">
				<legend>Méridiens et Merveilleux Vaisseaux</legend>
				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data']->value, 'row');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['row']->value) {
?>
				<div class="inputMer">
					<ul>
							<li>
								<input type="checkbox" name="<?php echo $_smarty_tpl->tpl_vars['row']->value['code'];?>
" id="<?php echo $_smarty_tpl->tpl_vars['row']->value['code'];?>
"><label for="<?php echo $_smarty_tpl->tpl_vars['row']->value['code'];?>
"><?php echo $_smarty_tpl->tpl_vars['row']->value['nom'];?>
</label>
							</li>
						
					</ul>

				</div>
				<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
				<input type="button" value="Tout cocher" onclick="this.value=check('fs_mer')">
			</fieldset>
		</form>
	</body>
</html>
<?php }
}
