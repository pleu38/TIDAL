<?php
/* Smarty version 3.1.33, created on 2019-09-12 12:07:49
  from 'C:\wamp64\www\appli\templates\defaut.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5d7a35150ceb58_94897130',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '98baf0e45ac393a363ac650ac73fe9e32c5d6fef' => 
    array (
      0 => 'C:\\wamp64\\www\\appli\\templates\\defaut.tpl',
      1 => 1568027925,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5d7a35150ceb58_94897130 (Smarty_Internal_Template $_smarty_tpl) {
?><!--?xml version="1.0" encoding="UTF-8"?-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
		<meta name="description" content="whatever"/>
		<link href="styles/style.css" rel="stylesheet" type="text/css"/>
		<?php echo '<script'; ?>
 type="text/javascript" src="js/pathos.js" charset="utf-8"><?php echo '</script'; ?>
>
	</head>
	<body>
	<div id="content">
		<p>Pas de template associé</p>
		<p>Essayez peut-être <a href="http://localhost/appli/?action=test">http://localhost/appli/?action=test</a>?</p>
	</div>
</body>
</html>
<?php }
}
