<?php

foreach($_POST as $cle => $element)
	$element

?>
