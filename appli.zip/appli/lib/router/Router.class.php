<?php
/**

	Routeur de base
	Mettre à jour la map mapTpl pour l'ajout d'une nouvelle vue
	Vous pouvez également créer d'autres classes spécifiant chaque routage particulier 
	ou plus simplement mais moins proprement commencer par gérer ici toutes les routes
*/
require 'lib/bd/bd.class.php';

class Router
{
	private $smarty = null;
	private $action = "";
	const mapTpl = array(
		"test" => "templates/exemple.tpl",
		"bdd" => "templates/bdd.tpl",
		"fil" => "templates/fil.tpl",
		"affichage" => "templates/affichage.tpl"
		
	);
	
	function __construct($smarty,$action ){
		$this->smarty = $smarty;
		if(isset(Router::mapTpl[$action])){
				$this->action = $action;
		}
	}
	
	//page par defaut
	function getTpl(){  
		$ret = "templates/defaut.tpl";
		if($this->action!=""){
			$ret = Router::mapTpl[$this->action];
			$this->todo();
		}
		
		return $ret;
	}
	
	function todo(){
		
		$this->smarty->assign("userFirstName",get_current_user());
	}
	
	function traitement(){
		
		switch ($this->action) {
			case 'bdd':

					$maBD = new BD();
					
					$resultat = $maBD->requete("SELECT * FROM meridien order by nom;");
					//var_dump($resultat);
					$this->smarty->assign("data",$resultat);
					
					
					$resultat = $maBD->requete("SELECT * FROM patho order by mer;");
					$this->smarty->assign("douleur",$resultat);
			
			break;
			case 'affichage':
					$maBD = new BD();
					foreach($_POST as $cle => $element){
						
						$screen = $maBD->requete(
							"SELECT distinct s.idS, s.desc FROM symptome s JOIN symptpatho sp on s.idS=sp.idS JOIN patho pa on sp.idP = pa.idP WHERE mer = :meridien order by s.idS ;",
							array(
								":meridien" => $cle
							)
						);
						//var_dump($screen);
						$this->smarty->assign("screen",$screen);
					}
			break;
			
			//case 'fil':

					//$maBD = new BD();
					
					//$resultat = $maBD->requete("SELECT * FROM meridien order by nom;");
					//var_dump($resultat);
					//$this->smarty->assign("data",$resultat);
					
					
				//	break;
			default;
				//printf("entrer ");
		}
	}
}

?>
