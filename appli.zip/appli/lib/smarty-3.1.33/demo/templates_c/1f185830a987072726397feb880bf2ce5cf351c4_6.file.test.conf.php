<?php /* Smarty version 3.1.33, created on 2019-09-08 21:53:03
         compiled from '/home/bruno/travail/ens/cpe/4ETI/tli/tps/appli/lib/smarty-3.1.33/demo/configs/test.conf' */ ?>
<?php
/* Smarty version 3.1.33, created on 2019-09-08 21:53:03
  from '/home/bruno/travail/ens/cpe/4ETI/tli/tps/appli/lib/smarty-3.1.33/demo/configs/test.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5d755c1fc445d7_08609790',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1f185830a987072726397feb880bf2ce5cf351c4' => 
    array (
      0 => '/home/bruno/travail/ens/cpe/4ETI/tli/tps/appli/lib/smarty-3.1.33/demo/configs/test.conf',
      1 => 1567971224,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5d755c1fc445d7_08609790 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'setup' => 
    array (
      'vars' => 
      array (
        'bold' => true,
      ),
    ),
  ),
  'vars' => 
  array (
    'title' => 'Welcome to Smarty!',
    'cutoff_size' => 40,
  ),
));
}
}
