<?php
/* Smarty version 3.1.33, created on 2019-09-08 21:53:03
  from '/home/bruno/travail/ens/cpe/4ETI/tli/tps/appli/lib/smarty-3.1.33/demo/templates/header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5d755c1fc47206_04959236',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '27dbc6c4e9a73d9ece81bde8a74536077d11f631' => 
    array (
      0 => '/home/bruno/travail/ens/cpe/4ETI/tli/tps/appli/lib/smarty-3.1.33/demo/templates/header.tpl',
      1 => 1567971224,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5d755c1fc47206_04959236 (Smarty_Internal_Template $_smarty_tpl) {
?><HTML>
<HEAD>
<TITLE><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - <?php echo $_smarty_tpl->tpl_vars['Name']->value;?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<?php }
}
