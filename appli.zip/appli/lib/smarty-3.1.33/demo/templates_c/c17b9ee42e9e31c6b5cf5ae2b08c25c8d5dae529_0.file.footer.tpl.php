<?php
/* Smarty version 3.1.33, created on 2019-09-08 21:53:03
  from '/home/bruno/travail/ens/cpe/4ETI/tli/tps/appli/lib/smarty-3.1.33/demo/templates/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5d755c1fc4c669_40187478',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c17b9ee42e9e31c6b5cf5ae2b08c25c8d5dae529' => 
    array (
      0 => '/home/bruno/travail/ens/cpe/4ETI/tli/tps/appli/lib/smarty-3.1.33/demo/templates/footer.tpl',
      1 => 1567971224,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5d755c1fc4c669_40187478 (Smarty_Internal_Template $_smarty_tpl) {
?></BODY>
</HTML>
<?php }
}
